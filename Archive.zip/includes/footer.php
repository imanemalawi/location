<center>
	<table>
		<tr>
			<td align="right" class="contact_a_propos">
						<a href="#">
							<i class="fa fa-phone"> </i> Contacts
						</a> |
						<a href="#">
							<i class="fa fa-info-circle"> </i> A propos
						</a> |
						<a href="#">
							<i class="fa fa-bookmark"> </i> Mentions légales
						</a> |
						<a href="/site-location-vehicule/authentification_admin/">
							<i class="fa fa-user"> </i><i class="fa fa-cogs"> </i> Administration
						</a>
					</td>
		</tr>
	</table>
</center>