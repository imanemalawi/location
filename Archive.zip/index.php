<?php

require 'Controleur/Routeur.php';

$routeur = new Routeur();
$routeur->routerRequete();
