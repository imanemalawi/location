<div class="wheel-start">
		<img src="images/bg1.jpg" alt="" class="wheel-img">
		<div class="container padd-lr0">
				<div class="col-lg-6 col-lg-push-6 ">
						<header class="wheel-header marg-lg-b100 marg-lg-t200  marg-md-b0 marg-md-t0">
								<h1>Local Luxe  </h1>
								<h2>Recherche - Louer - Comparer - Moins cher </h2>
								
						</header>
				</div>
				<div class="col-lg-6 col-lg-pull-6  padd-lr0">
						<div class="wheel-start-form">
								<form action="#">
										<label for="input-val11"><span>Ville Depart</span>
										<input type="text" id='input-val11' placeholder="ZIP, City, Airport or Address" required>
										</label>
										<label for="input-val12"><span>Ville Fin</span>
										<input type="text" id='input-val12' placeholder="ZIP, City, Airport or Address" required>
										</label>
										<div class="clearfix">
												<div class="wheel-date">
														<span>Date Debut</span>
														<label for="input-val13" class="fa fa-calendar">
														<input  class="datetimepicker" id='input-val13' type="text" value="29 Apr">
														</label>
												</div>

												<div class="wheel-date">
														<span>Date Fin</span>
														<label for="input-val15" class="fa fa-calendar">
														<input  class="datetimepicker" id='input-val15' type="text" value="29 Apr">
														</label>
												</div>

												<div class="wheel-date">
														<span>Age</span>
														<select class="selectpicker">
																<option>21</option>
																<option>22</option>
																<option>23</option>
								<								<option>24</option>
																<option>25</option>
																<option>26</option>
																<option>27</option>
																<option>28</option>
																<option>29</option>
																<option>30</option>
																<option>31</option>
																<option>32</option>
																<option>33</option>
																<option>34</option>
																<option>35</option>
																<option>36</option>
																<option>37</option>
																<option>38</option>
																<option>39</option>
																<option>40</option>
																<option>41</option>
																<option>42</option>
																<option>43</option>
																<option>44</option>
																<option>45</option>
																<option>46</option>
																<option>47</option>
																<option>48</option>
																<option>49</option>
																<option>50</option>
														</select>
												</div>
												<div class="wheel-date">
														<span>Ville</span>
														<select class="selectpicker">
																<option>Tanger</option>
																<option>Casablanca</option>
																<option>Rabat</option>
																<option>Fes</option>
																<option>Merakech</option>
																<option>Tetoin</option>
																<option>Agadir</option>
														</select>
												</div>
										</div>
										
										<label for="input-val18" class="promo promo2">
										<button class="wheel-btn" id="input-val18">Recherche</button>
										</label>
								</form>
						</div>
				</div>
		</div>
</div>


<div class="wheel-collection wheel-bg2">
		<div class="container">
				<div class="row">
						<div class="col-xs-12">
								<div class="wheel-header text-center marg-lg-t140 marg-lg-b65  marg-md-t50 ">
										<h5>Nous avons la meilleure Collection </h5>
										<h3>collection de <span>vehicles</span></h3>
								</div>
						</div>
				</div>
				<div class="row">
						<div class="col-lg-12 ">
								<div class="tabs">
										<div class="tabs-header">
												<ul>
														
														<li><a href="#">Nouveaute</a></li>
														
												</ul>
										</div>
										<div class="tabs-content  marg-lg-b30">
												<div class="tabs-item active ">
														<div class="swiper-container" data-autoplay="0" data-touch="1" data-mouse="0" data-xs-slides="1" data-sm-slides="2" data-md-slides="4" data-lg-slides="6" data-add-slides="6" data-slides-per-view="responsive" data-loop="1" data-speed="1000">
																<div class="swiper-wrapper">
																		<div class="swiper-slide">
																				<div  data-name='2016 Nissan Juke' data-carClass='Luxury Sports Car' data-price='$100' data-text='Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsu nec sagittis sem nibh id elit.' data-bags='2 Bags' data-passenger='2 PASSENGERS' data-speed='5.6/100 MPG' data-img='images/z-car-1.png'><img src="images/3.png" height="120px"></div>
																		</div>
																		<div class="swiper-slide">
																				<div  data-name='2016 Chevrolet Malibu' data-carClass='Luxury Sports Car' data-price='$100' data-text='Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsu nec sagittis sem nibh id elit.' data-bags='2 Bags' data-passenger='2 PASSENGERS' data-speed='5.6/100 MPG' data-img='images/i32.jpg'><img src="images/4.png" height="120px"></div>
																		</div>
																		<div class="swiper-slide">
																				<div  data-name='Bugatti Veyron' data-carClass='Luxury Sports Car' data-price='2' data-text='Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsu nec sagittis sem nibh id elit.' data-bags='2 Bags' data-passenger='2 PASSENGERS' data-speed='5.6/100 MPG' data-img='images/i33.jpg'><img src="images/5.png" height="120px"></div>
																		</div>
																		<div class="swiper-slide">
																				<div data-name='2016 Audi S4' data-carClass='Luxury Sports Car' data-price='$10' data-text='Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsu nec sagittis sem nibh id elit.' data-bags='2 Bags' data-passenger='2 PASSENGERS' data-speed='5.6/100 MPG' data-img='images/i34.jpg'><img src="images/6.png" height="120px"></div>
																		</div>
																		<div class="swiper-slide">
																				<div    data-passenger='2 PASSENGERS' data-speed='5.6/100 MPG' ><img src="images/7.png" height="120px"></div>
																		</div>
																		<div class="swiper-slide">
																				<div data-name='Porsche Boxter Spyder' data-carClass='Luxury Sports Car' data-price='4' data-text='Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsu nec sagittis sem nibh id elit.' data-bags='2 Bags' data-passenger='2 PASSENGERS' data-speed='5.6/100 MPG' data-img='images/i37.jpg'><img src="images/8.png" height="120px"></div>
																		</div>
																</div>
																<div class="swiper-arrow-left fa fa-angle-left"></div>
																<div class="swiper-arrow-right fa fa-angle-right"></div>
																<div class="pagination"></div>
														</div>
												</div>
												
																<div class="swiper-arrow-left fa fa-angle-left"></div>
																<div class="swiper-arrow-right fa fa-angle-right"></div>
																<div class="pagination"></div>
														</div>
												</div>
										</div>
								</div>
						</div>
				</div>
				
<!-- ////////////////////////////////////////////// -->

