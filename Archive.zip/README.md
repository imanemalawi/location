# site-location-vehicule
Site de location de véhicules en ligne

## Membre du groupe
- DAHCHAR MOHAMMED SAID
- EL HADDAJI MOHAMED AMINE
- MALAWI IMANE
- SALMOUN INSAF
 

## Objectif
Nous souhaitons nous doter d'un site de location de véhicules en ligne.

## Travail demandé
Il vous est demandé de mettre en place un site permettant de créer, modifier, afficher et supprimer des véhicules. Il doit permettre à un utilisateur (internaute) de réserver un véhicule qu'il désire louer. Il doit être en mesure de vérifier la disponibilité du véhicule pour la période choisie par l'utilisateur.

## Quoi utiliser ?
Il est recommandé :
- d'utiliser Framework PHP pour faciliter le développement;
- une base de données MySQL;

## Technologies
On utilisera donc PHP et MySQL . Ce dernier servant ici pour dynamiser le site web et envoyer des requêtes asynchrones au serveur web.

